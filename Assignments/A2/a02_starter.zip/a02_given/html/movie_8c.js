var movie_8c =
[
    [ "genres_menu", "movie_8c.html#a4e18afc31d970298b1648e1c030ec311", null ],
    [ "movie_compare", "movie_8c.html#a7f147935fddf15c50e005e2e214ff121", null ],
    [ "movie_copy", "movie_8c.html#ab64dc655f2d623720578151c5674c49a", null ],
    [ "movie_init", "movie_8c.html#aeb44c6ee71262fb48b69324afd1b7a38", null ],
    [ "movie_key", "movie_8c.html#a3f4363f226b7d444ecbc31d13ec5f74f", null ],
    [ "movie_print", "movie_8c.html#a49f536fc0aadf11f5bd2c5ca05982bc1", null ]
];