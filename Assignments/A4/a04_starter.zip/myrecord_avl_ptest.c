#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "myrecord_avl.h"

// Function prototype for calculate_stats
void calculate_stats(AVLDS *ds);

// Helper function to test if tree is AVL balanced
int is_avl(AVLNODE *root) {
    if (root == NULL) return 1;
    
    int bal = balance_factor(root);
    if (bal > 1 || bal < -1) return 0;
    
    return is_avl(root->left) && is_avl(root->right);
}

// Helper function to populate an AVL tree with test data
void populate_test_data(AVLDS *ds) {
    RECORD records[] = {
        {"A1", 10.0}, {"A2", 20.0}, {"A3", 30.0}, {"A4", 40.0}, {"A5", 50.0},
        {"A6", 60.0}, {"A7", 70.0}, {"A8", 80.0}, {"A9", 90.0}, {"A10", 100.0}
    };
    
    for (int i = 0; i < 10; i++) {
        add_record(ds, records[i]);
    }
}

// Helper function to display statistics
void display_stats(AVLDS *ds) {
    printf("count %d mean %.1f stddev %.1f\n", ds->count, ds->mean, ds->stddev);
}

int main() {
    // Initialize test structures
    AVLNODE *avlA = NULL;
    AVLNODE *avlB = NULL;
    AVLDS avldsA = {NULL, 0, 0.0, 0.0};
    AVLDS avldsB = {NULL, 0, 0.0, 0.0};
    AVLDS avldsC = {NULL, 0, 0.0, 0.0};

    // Test merge_avl
    printf("**Test: merge_avl**\n");
    
    // Create test data for avlA and avlB
    RECORD recordsA[] = {{"A1", 10.0}, {"A2", 20.0}};
    RECORD recordsB[] = {{"B1", 30.0}, {"B2", 40.0}};
    
    for (int i = 0; i < 2; i++) {
        avl_insert(&avlA, recordsA[i]);
        avl_insert(&avlB, recordsB[i]);
    }
    
    printf("is_avl(avlA): %d\n", is_avl(avlA));
    printf("is_avl(avlB): %d\n", is_avl(avlB));
    
    merge_avl(&avlA, avlB);
    printf("merge_avl(avlA avlB): %d\n", is_avl(avlA));
    
    // Clean up first test
    avl_clean(&avlA);
    avl_clean(&avlB);
    
    printf("** **\n");
    
    // Test merge_avlds
    printf("**Test: merge_avlds**\n");
    
    // Populate test data
    populate_test_data(&avldsA);
    populate_test_data(&avldsB);
    
    // Create avldsC as a reference for comparison
    merge_avlds(&avldsB, &avldsA); // Merge avldsA into avldsB
    calculate_stats(&avldsB); // Calculate stats for avldsB after merging
    avldsC = avldsB; // Copy merged results to avldsC for comparison
    
    printf("display_stats(avldsA): ");
    display_stats(&avldsA);
    
    printf("display_stats(avldsB): ");
    display_stats(&avldsB);
    
    printf("display_stats(avldsC): ");
    display_stats(&avldsC);
    
    // Clean up
    avlds_clean(&avldsA);
    avlds_clean(&avldsB);
    avlds_clean(&avldsC);
    
    return 0;
}