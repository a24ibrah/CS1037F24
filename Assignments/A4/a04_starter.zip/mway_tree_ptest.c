#include "mway_tree.h"

int main() {
    TNODE* root = NULL;
    
    // Test: Insert and Display
    printf("Test: Insert and Display\n");
    printf("insert_key(root, 22)\n");
    insert_key(&root, 22);
    printf("insert_key(root, 5)\n");
    insert_key(&root, 5);
    printf("insert_key(root, 10)\n");
    insert_key(&root, 10);
    
    printf("display_tree(root):\n");
    display_tree(root);
    printf("\n");
    
    // Test: In-Order Traversal
    printf("Test: In-Order Traversal\n");
    printf("print_inorder(root): ");
    print_inorder(root);
    printf("\n\n");
    
    // Test: Search Key
    printf("Test: Search Key\n");
    printf("search_key(root, 10): %s\n", 
           search_key(root, 10) ? "Found" : "Not Found");
    printf("search_key(root, 15): %s\n", 
           search_key(root, 15) ? "Found" : "Not Found");
    printf("\n");
    
    // Test: Delete Key
    printf("Test: Delete Key\n");
    printf("delete_key(root, 10)\n");
    delete_key(&root, 10);
    printf("display_tree(root):\n");
    display_tree(root);
    
    return 0;
}