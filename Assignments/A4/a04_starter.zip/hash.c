#include "hash.h"

int hash(char* key, int size) {
    int sum = 0;
    for (int i = 0; key[i] != '\0'; i++) {
        sum += (int)key[i];
    }
    return sum % size;
}

HASHTABLE* new_hashtable(int size) {
    HASHTABLE* ht = (HASHTABLE*)malloc(sizeof(HASHTABLE));
    if (!ht) return NULL;
    
    ht->size = size;
    ht->count = 0;
    ht->hna = (HASHNODE**)calloc(size, sizeof(HASHNODE*));
    
    if (!ht->hna) {
        free(ht);
        return NULL;
    }
    
    return ht;
}

int hashtable_insert(HASHTABLE* ht, char* key, int value) {
    if (!ht || !key) return 0;
    
    int index = hash(key, ht->size);
    HASHNODE* current = ht->hna[index];
    HASHNODE* prev = NULL;
    
    // Search for existing key and maintain sorted order
    while (current && strcmp(current->key, key) < 0) {
        prev = current;
        current = current->next;
    }
    
    // If key already exists, update value
    if (current && strcmp(current->key, key) == 0) {
        current->value = value;
        return 1;
    }
    
    // Create new node
    HASHNODE* newNode = (HASHNODE*)malloc(sizeof(HASHNODE));
    if (!newNode) return 0;
    
    strncpy(newNode->key, key, MAX_KEY_LENGTH - 1);
    newNode->key[MAX_KEY_LENGTH - 1] = '\0';
    newNode->value = value;
    
    // Insert new node
    if (!prev) {
        newNode->next = ht->hna[index];
        ht->hna[index] = newNode;
    } else {
        newNode->next = current;
        prev->next = newNode;
    }
    
    ht->count++;
    return 1;
}

HASHNODE* hashtable_search(HASHTABLE* ht, char* key) {
    if (!ht || !key) return NULL;
    
    int index = hash(key, ht->size);
    HASHNODE* current = ht->hna[index];
    
    while (current) {
        if (strcmp(current->key, key) == 0) {
            return current;
        }
        current = current->next;
    }
    
    return NULL;
}

int hashtable_delete(HASHTABLE* ht, char* key) {
    if (!ht || !key) return 0;
    
    int index = hash(key, ht->size);
    HASHNODE* current = ht->hna[index];
    HASHNODE* prev = NULL;
    
    while (current) {
        if (strcmp(current->key, key) == 0) {
            if (prev) {
                prev->next = current->next;
            } else {
                ht->hna[index] = current->next;
            }
            free(current);
            ht->count--;
            return 1;
        }
        prev = current;
        current = current->next;
    }
    
    return 0;
}

void hashtable_clean(HASHTABLE** ht) {
    if (!ht || !*ht) return;
    
    // Free all nodes in each bucket
    for (int i = 0; i < (*ht)->size; i++) {
        HASHNODE* current = (*ht)->hna[i];
        while (current) {
            HASHNODE* temp = current;
            current = current->next;
            free(temp);
        }
    }
    
    // Free the array of bucket pointers
    free((*ht)->hna);
    
    // Free the hashtable structure itself
    free(*ht);
    *ht = NULL;
}