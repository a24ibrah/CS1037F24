#ifndef MYRECORD_AVL_H
#define MYRECORD_AVL_H

#include "avl.h"

typedef struct {
    AVLNODE *root;
    int count;
    float mean;
    float stddev;
} AVLDS;

// Merge source AVL tree into destination AVL tree
void merge_avl(AVLNODE **rootp_dest, AVLNODE *rootp_source);

// Merge source AVLDS into destination AVLDS
void merge_avlds(AVLDS *source, AVLDS *dest);

// Clean AVLDS structure
void avlds_clean(AVLDS *ds);

// Add a record to AVLDS
void add_record(AVLDS *ds, RECORD data);

// Remove a record from AVLDS by name
void remove_record(AVLDS *ds, char *name);

// Calculate statistics (mean and standard deviation)
void calculate_stats(AVLDS *ds);

#endif // MYRECORD_AVL_H