#include "hash.h"

void print_hashtable(HASHTABLE* ht) {
    printf("count %d ", ht->count);
    for (int i = 0; i < ht->size; i++) {
        HASHNODE* current = ht->hna[i];
        if (current) {
            printf("%d ", i);
            while (current) {
                printf("(%s %d) ", current->key, current->value);
                current = current->next;
            }
        }
    }
    printf("\n");
}

int main() {
    // Test hash function
    printf("Test for hash:\n");
    printf("hash(a): %d\n", hash("a", 5));
    printf("hash(b): %d\n", hash("b", 5));
    printf("hash(c): %d\n", hash("c", 5));
    printf("hash(d): %d\n", hash("d", 5));
    
    // Test new_hashtable
    printf("\nTest for new_hashtable:\n");
    HASHTABLE* ht = new_hashtable(5);
    printf("new_hashtable(5): size %d count %d\n", ht->size, ht->count);
    
    // Test hashtable_insert
    printf("\nTest for hashtable_insert:\n");
    printf("hashtable_insert(a 0): ");
    hashtable_insert(ht, "a", 0);
    print_hashtable(ht);
    
    printf("hashtable_insert(b 1): ");
    hashtable_insert(ht, "b", 1);
    print_hashtable(ht);
    
    printf("hashtable_insert(d 3): ");
    hashtable_insert(ht, "d", 3);
    print_hashtable(ht);
    
    // Test hashtable_search
    printf("\nTest for hashtable_search:\n");
    HASHNODE* node;
    
    node = hashtable_search(ht, "a");
    printf("search(a): %s\n", node ? node->key : "NULL");
    
    node = hashtable_search(ht, "b");
    printf("search(b): %s\n", node ? node->key : "NULL");
    
    node = hashtable_search(ht, "f");
    printf("search(f): %s\n", node ? node->key : "NULL");
    
    node = hashtable_search(ht, "h");
    printf("search(h): %s\n", node ? node->key : "NULL");
    
    // Add more entries for delete test
    hashtable_insert(ht, "c", 2);
    hashtable_insert(ht, "e", 4);
    hashtable_insert(ht, "f", 5);
    hashtable_insert(ht, "g", 6);
    
    // Test hashtable_delete
    printf("\nTest for hashtable_delete:\n");
    printf("hashtable_delete(a):\n");
    hashtable_delete(ht, "a");
    print_hashtable(ht);
    
    printf("hashtable_delete(b):\n");
    hashtable_delete(ht, "b");
    print_hashtable(ht);
    
    // Clean up
    hashtable_clean(&ht);
    
    return 0;
}