#ifndef HASH_H
#define HASH_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_KEY_LENGTH 21  // 20 chars + null terminator

typedef struct {
    char key[MAX_KEY_LENGTH];
    int value;
} HASHDATA;

typedef struct hashnode {
    char key[MAX_KEY_LENGTH];
    int value;
    struct hashnode* next;
} HASHNODE;

typedef struct {
    HASHNODE** hna;
    int size;
    int count;
} HASHTABLE;

// Function prototypes
int hash(char* key, int size);
HASHTABLE* new_hashtable(int size);
int hashtable_insert(HASHTABLE* ht, char* key, int value);
HASHNODE* hashtable_search(HASHTABLE* ht, char* key);
int hashtable_delete(HASHTABLE* ht, char* key);
void hashtable_clean(HASHTABLE** ht);

#endif