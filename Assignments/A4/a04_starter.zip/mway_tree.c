#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "myrecord_avl.h"

// Helper function to copy a node's data
static RECORD copy_record(RECORD src) {
    RECORD dest;
    strcpy(dest.name, src.name);
    dest.score = src.score;
    return dest;
}

// Helper function to traverse tree and collect sums for statistics
static void collect_sums(AVLNODE *root, double *sum, double *sum_squares) {
    if (root) {
        *sum += root->data.score;
        *sum_squares += root->data.score * root->data.score;
        collect_sums(root->left, sum, sum_squares);
        collect_sums(root->right, sum, sum_squares);
    }
}

// Helper function for in-order traversal and merging
static void traverse_and_merge(AVLNODE *root, AVLNODE **dest) {
    if (root) {
        traverse_and_merge(root->left, dest);
        avl_insert(dest, copy_record(root->data));
        traverse_and_merge(root->right, dest);
    }
}

void merge_avl(AVLNODE **rootp_dest, AVLNODE *rootp_source) {
    if (!rootp_source) return;
    traverse_and_merge(rootp_source, rootp_dest);
}

void merge_avlds(AVLDS *source, AVLDS *dest) {
    if (!source || !dest) return;

    // Merge the trees
    merge_avl(&dest->root, source->root);
    
    // Update destination statistics
    calculate_stats(dest);
    
    // Clean source
    avlds_clean(source);
}

void avlds_clean(AVLDS *ds) {
    if (!ds) return;
    
    // Clean the AVL tree
    avl_clean(&ds->root);
    
    // Reset statistics
    ds->count = 0;
    ds->mean = 0.0;
    ds->stddev = 0.0;
}

void add_record(AVLDS *ds, RECORD data) {
    if (!ds) return;
    
    // Add record to AVL tree
    avl_insert(&ds->root, data);
    
    // Recalculate statistics
    calculate_stats(ds);
}

void remove_record(AVLDS *ds, char *name) {
    if (!ds || !name) return;
    
    // Remove record from AVL tree
    avl_delete(&ds->root, name);
    
    // Recalculate statistics
    calculate_stats(ds);
}

void calculate_stats(AVLDS *ds) {
    if (!ds) return;
    
    // Reset statistics
    ds->count = 0;
    ds->mean = 0.0;
    ds->stddev = 0.0;
    
    // Get count of nodes
    ds->count = avl_count_nodes(ds->root);
    
    if (ds->count == 0) return;
    
    // Calculate sum and sum of squares
    double sum = 0.0;
    double sum_squares = 0.0;
    collect_sums(ds->root, &sum, &sum_squares);
    
    // Calculate mean
    ds->mean = (float)(sum / ds->count);
    
    // Calculate standard deviation
    if (ds->count > 1) {
        double variance = (sum_squares - (sum * sum / ds->count)) / (ds->count - 1);
        ds->stddev = (float)sqrt(variance);
    }
}