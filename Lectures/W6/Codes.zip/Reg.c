#include <stdio.h>

int main(void)   
{
    // 1. Declare a file pointer
    FILE *fp; 

    // 2. Declare a character array to 
    // store the user's name and an integer for age           
    char name[10];    
    int age;   
    
    // 3. Open the file in write mode
    fp = fopen("rec.dat", "w");   
    if (fp == NULL) 
    {   
        // Return an error code if the file can't be opened
        printf("Error opening file!\n");
        return 1;        
    }

    // 4. Prompt user for input
    printf("Enter your name and age: ");

    // 5. Take user input for the name and age
    scanf("%s %d", name, &age);    

    // 6. Check if the input is valid
    if (age <= 0) {
        printf("Invalid age. Please enter a positive number.\n");
        fclose(fp);
        return 1;
    }
    
    // 7. Write the name and age to the file
    fprintf(fp, "Name: %s, Age: %d\n", name, age);  
    
    // 8. Close the file
    fclose(fp);           

    printf("Name and age saved successfully!\n");
    return 0;
}
