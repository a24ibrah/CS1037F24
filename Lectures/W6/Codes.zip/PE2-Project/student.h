/*
Include guard. 
The purpose of include guards is to prevent multiple inclusions of the same header file
within a single compilation process, which can lead to errors such as redefinition of variables,
structures, or functions.
*/

#ifndef STUDENT_H
#define STUDENT_H


// Define the structure for the student
struct student {
    char SID[10];  // Student ID
    char name[20]; // Student Name
};

// Function prototypes
void write_record(FILE *fptr, int record_num);
void read_record(FILE *fptr, int record_num);

#endif
