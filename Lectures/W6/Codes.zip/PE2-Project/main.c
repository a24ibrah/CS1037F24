#include <stdio.h>
#include "student.h" // Contains the struct definition and function prototypes


int main() {
    FILE *fptr;
    int choice, record_num;

    // Try to open the file in read/write mode, or create it if it doesn't exist
    fptr = fopen("students.dat", "rb+");
    if (fptr == NULL) {
        fptr = fopen("students.dat", "wb+");
        if (fptr == NULL) {
            printf("Error opening file!\n");
            return 1;
        }
    }

    // Get user choice for reading or writing
    printf("Enter 1 to write a record, 2 to read a record: ");
    scanf("%d", &choice);
    getchar();  // Clear the newline character from the input buffer

    if (choice == 1) {
        printf("Enter record number to write: ");
        scanf("%d", &record_num);
        getchar();  // Clear the newline character
        write_record(fptr, record_num);
    } else if (choice == 2) {
        printf("Enter record number to read: ");
        scanf("%d", &record_num);
        read_record(fptr, record_num);
    } else {
        printf("Invalid choice!\n");
    }

    fclose(fptr);
    return 0;
}
