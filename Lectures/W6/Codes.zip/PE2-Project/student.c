#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "student.h"

// Function to write a record to the file
void write_record(FILE *fptr, int record_num) {
    struct student st;

    // Get user input for SID and name
    printf("Enter student ID: ");
    fgets(st.SID, sizeof(st.SID), stdin);
    st.SID[strcspn(st.SID, "\n")] = '\0';  // Remove newline character

    printf("Enter name: ");
    fgets(st.name, sizeof(st.name), stdin);
    st.name[strcspn(st.name, "\n")] = '\0';  // Remove newline character

    // Move the file pointer to the appropriate position
    fseek(fptr, record_num * sizeof(struct student), SEEK_SET);

    // Write the record to the file
    fwrite(&st, sizeof(struct student), 1, fptr);
    printf("Record written successfully!\n");
}

// Function to read a record from the file
void read_record(FILE *fptr, int record_num) {
    struct student st;

    // Move the file pointer to the appropriate position
    fseek(fptr, record_num * sizeof(struct student), SEEK_SET);

    // Read the record from the file
    if (fread(&st, sizeof(struct student), 1, fptr) == 1) {
        // Display the student's information
        printf("Student ID: %s\n", st.SID);
        printf("Name: %s\n", st.name);
    } else {
        printf("No record found at this position!\n");
    }
}