#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Define the structure for the student
struct student {
    char SID[10];  // Student ID
    char name[20]; // Student Name
};

// Function to write a record to the file
void write_record(FILE *fptr, int record_num) {
    struct student st;

    // Get user input for SID and name
    printf("Enter student ID: ");
    fgets(st.SID, sizeof(st.SID), stdin);
    st.SID[strcspn(st.SID, "\n")] = '\0';  // Remove newline character

    printf("Enter name: ");
    fgets(st.name, sizeof(st.name), stdin);
    st.name[strcspn(st.name, "\n")] = '\0';  // Remove newline character

    // Move the file pointer to the appropriate position
    fseek(fptr, record_num * sizeof(struct student), SEEK_SET);

    // Write the record to the file
    fwrite(&st, sizeof(struct student), 1, fptr);
    printf("Record written successfully!\n");
}

// Function to read a record from the file
void read_record(FILE *fptr, int record_num) {
    struct student st;

    // Move the file pointer to the appropriate position
    fseek(fptr, record_num * sizeof(struct student), SEEK_SET);

    // Read the record from the file
    if (fread(&st, sizeof(struct student), 1, fptr) == 1) {
        // Display the student's information
        printf("Student ID: %s\n", st.SID);
        printf("Name: %s\n", st.name);
    } else {
        printf("No record found at this position!\n");
    }
}

int main() {
    FILE *fptr;
    int choice, record_num;

    // Try to open the file in read/write mode, or create it if it doesn't exist
    fptr = fopen("students.dat", "rb+");
    if (fptr == NULL) {
        fptr = fopen("students.dat", "wb+");
        if (fptr == NULL) {
            printf("Error opening file!\n");
            return 1;
        }
    }

    // Get user choice for reading or writing
    printf("Enter 1 to write a record, 2 to read a record: ");
    scanf("%d", &choice);
    getchar();  // Clear the newline character from the input buffer

    if (choice == 1) {
        printf("Enter record number to write: ");
        scanf("%d", &record_num);
        getchar();  // Clear the newline character
        write_record(fptr, record_num);
    } else if (choice == 2) {
        printf("Enter record number to read: ");
        scanf("%d", &record_num);
        read_record(fptr, record_num);
    } else {
        printf("Invalid choice!\n");
    }

    fclose(fptr);
    return 0;
}
