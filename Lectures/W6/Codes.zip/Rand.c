#include <stdio.h>
#include <errno.h>
#include <string.h>

int main(void) {
    // Declare a file pointer
    FILE *fp;

    // Open the file in write mode ("wb+" creates the file if it doesn't exist)
    // Using relative path, file should be created in the project directory
    fp = fopen("data.dat", "wb+");  
    
    if (fp == NULL) {
        // Print the error if file cannot be opened
        printf("Error opening file: %s\n", strerror(errno));  
        fclose(fp);
        return 1;
    }
    /*strerror(errno) is a C library function that returns a human-readable string 
    describing the error code stored in the global variable errno. */

    // Array to write to the file
    int data[5] = {10, 20, 30, 40, 50};

    // Write array of 5 integers to the file
    if (fwrite(data, sizeof(int), 5, fp) != 5) {
        printf("Error writing to file.\n");
        fclose(fp);
        return 1;
    }
    printf("Data successfully written to file.\n");

    // Move file pointer back to the start for reading
    rewind(fp);

    // Array to store the data read from the file
    int read_data[5];
    if (fread(read_data, sizeof(int), 5, fp) != 5) {
        printf("Error reading from file.\n");
        fclose(fp);
        return 1;
    }

    // Print data read from the file
    printf("Data read from file: ");
    for (int i = 0; i < 5; i++) {
        printf("%d ", read_data[i]);
    }
    printf("\n");

    // Close the file
    fclose(fp);

    return 0;
}
