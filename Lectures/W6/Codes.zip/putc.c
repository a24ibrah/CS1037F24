#include <stdio.h>

int main() {
    FILE *fp;
    char c;
    int i;

    // Open file for writing
    fp = fopen("output.txt", "w");
    if (fp == NULL) {
        printf("Error opening file!\n");
        return 1;
    }

    // Loop to get 5 characters from user
    for (i = 0; i < 3; i++) {
        printf("Enter character %d: ", i+1);
        scanf(" %c", &c);
        fputc(c, fp);  // Write using fputc()
    }

    fclose(fp);
    printf("Characters written to file successfully!\n");

    return 0;
}
