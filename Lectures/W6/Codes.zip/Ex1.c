#include <stdio.h>
#include <stdlib.h>

int main(void) 
{
    FILE *fp;
    fp = fopen("data.txt", "w");

    if (fp == NULL) 
    {
        printf("Cannot open file\n");
        exit(1);
    }
    else
        printf("File opened successfully\n");

    // File operations can go here...

    fclose(fp);
    return 0;
}

