#include <stdio.h>
#include <stdlib.h>

int main() 
{
    FILE *ptr;
    char vote;
    // We have three candidates: A, B, and C
    // Initialize the vote counts to 0
    int countA = 0, countB = 0;
    int countC = 0, countOthers = 0;  

    // Open the file for reading
    ptr = fopen("votes.txt", "r");

    if (ptr == NULL) 
    {
        printf("Error: Could not open the file.\n");
        return 1;
    }

    // Read the votes from the file and tally them
    while ((vote = getc(ptr)) != EOF) 
    {
        if (vote == 'A')
            countA++;
        else if (vote == 'B')
            countB++;
        else if (vote == 'C')
            countC++;
            // Ignore newlines and spaces
        else if (vote != '\n' && vote != ' ')  
        // Count any other characters as invalid votes
        // or candidates
            countOthers++;  
    }

    // Close the file
    fclose(ptr);

    // Display the vote count for each candidate
    printf("Votes for Candidate A: %d\n", countA);
    printf("Votes for Candidate B: %d\n", countB);
    printf("Votes for Candidate C: %d\n", countC);
    printf("Invalid or other votes: %d\n", countOthers);

    return 0;
}
