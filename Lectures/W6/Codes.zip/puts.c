#include <stdio.h>

int main() {
    FILE *fp;
    char str[50];

    // Open file for writing
    fp = fopen("strings.txt", "w");
    if (fp == NULL) {
        printf("Error opening file!\n");
        return 1;
    }

    // Get string from user
    printf("Enter a string (up to 50 chars): ");
    fgets(str, 50, stdin);  // Use fgets to read the string

    // Write string to file
    fputs(str, fp);

    fclose(fp);
    printf("String written to file successfully!\n");

    return 0;
}
