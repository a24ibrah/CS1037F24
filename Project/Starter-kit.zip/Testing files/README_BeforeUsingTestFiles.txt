Usage Instructions

1. Place test files in the appropriate directory
2. Use the provided test files to run all tests
3. Compare results with expected outputs
4. Verify compression ratios
